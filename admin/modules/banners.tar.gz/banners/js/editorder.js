function AddNewData(dat) { $("#dataart .all").append("<input name='dataart[]' value='"+dat+"'>"); }
